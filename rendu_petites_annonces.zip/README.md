# Protocole d'exécution
1) exécuter : make
2) dans un terminal du PC 1, exécuter : java server.SercerTCP
3) dans un autre temrinal du PC 1, exécuter : java cient.Client
4) dans un terminal du PC2, exécuter : java client.Client

Vous avez alors un serveur et deux client. Réitérez l'opération 4) sur d'autre PC pour ouvrir d'autre clients.
